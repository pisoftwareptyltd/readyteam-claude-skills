---
name: readyteam-create-project-guide
description: Show the user how to create a project in ReadyTeam with an on-screen guide that highlights each button and field in their Chrome tab (Add Project, Project Name, Document Prefix, Home Address, Client, Create Project). The user does the clicking and typing; the guide moves on by itself. Use when the user asks how to create a project, wants to be shown or walked through creating a project, or after ReadyTeam onboarding imports are finished.
---

# ReadyTeam: guide the user to create a project

The user creates the project themselves. You only put a guide on their ReadyTeam page. The guide is one script (in the "Guide script" section at the end of this skill) that highlights each control and moves to the next one by itself as the user clicks and types. **Do not take screenshots step by step and do not click or type for the user.** That is what makes this fast.

## Steps

1. Load the Claude in Chrome tools in one ToolSearch call if they are deferred, including `javascript_tool`. Use the ReadyTeam tab that is already open (for example from onboarding); otherwise call `tabs_context_mcp`, open a new tab and go to **https://app.readyteam.ai/** (the staging site only if the user says so). If a login page shows, ask the user to sign in and reply "done".
2. Make sure the tab is on the ReadyTeam dashboard (the page with the orange **+ Add Project** button in the left sidebar). Navigate there if needed. No Create Project dialog should be open.
3. Run the full text of the guide script below, unchanged, in that tab with `javascript_tool`. It returns "ReadyTeam guide started: ...".
4. Tell the user in two or three plain lines, without waiting for anything else:
   "I've put a guide on your ReadyTeam screen. Follow the orange highlight: it shows you where to click and what to type, one step at a time. Tell me when your project is created, or if you get stuck."
5. Wait for the user. Do not poll or take screenshots while they work.
6. When they reply, run `window.__rtGuide && window.__rtGuide.status()` once with `javascript_tool`:
   - `finished: true`: the project was created. Take one screenshot to confirm the project page opened, and tell the user the project name shown.
   - not finished: ask what they see, or take one screenshot to understand where they are, and explain the next step in plain words. Run the script again if they want the guide back (it restarts cleanly).

## The steps the guide shows

1. Click **+ Add Project**.
2. Type the **Project Name**.
3. Type a **Document Prefix**: short (max 20 characters), no spaces, unique across their projects, for example the project initials.
4. Type the **Home Address** and pick it from the list if one appears.
5. Choose the **Client** (optional, Next skips it).
6. Click **Create Project**.

If ReadyTeam says the prefix is already used, tell the user to change it slightly (for example add 2 at the end) and click Create Project again. The guide stays on that step until the dialog closes.

## If the script can't run

If `javascript_tool` is not available or is refused, do not keep retrying. Give the user the six steps above as a short numbered list in plain words, and ask them to tell you when the project is created.

## Rules

- Never type into the form or click Create Project for the user, unless they ask you to.
- Do not change anything else in ReadyTeam.
- The guide closes with the Close guide button or Escape, and removes itself 15 seconds after the project is created.

## Status

Tested only on a mock page that mimics the Create New Project dialog. On the first real run, note whether each step found its button or field (a step that cannot find its control shows "I can't point to it right now"), and update the selectors in the guide script if needed.

## Guide script

```js
// ReadyTeam "create your first project" guide.
// Run once in the ReadyTeam tab. It highlights each control and moves on by
// itself as the user clicks and types; no screenshots are needed.
// Check progress afterwards with: window.__rtGuide.status()
(() => {
  if (window.__rtGuide && window.__rtGuide.stop) window.__rtGuide.stop();

  const Z = 2147483000;
  const ORANGE = '#ff7a00';

  const clean = (t) => (t || '').replace(/\*/g, '').replace(/\s+/g, ' ').trim();
  const visible = (el) => {
    if (!el || !el.getBoundingClientRect) return false;
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    const s = getComputedStyle(el);
    return s.visibility !== 'hidden' && s.display !== 'none' && s.opacity !== '0';
  };

  // The Create New Project dialog, if it is open.
  const dialog = () =>
    [...document.querySelectorAll('mat-dialog-container, [role=dialog], .modal.show, .cdk-overlay-pane')]
      .filter(visible)
      .find((d) => /create new project/i.test(d.innerText)) || null;
  const scope = () => dialog() || document;

  const FIELD_SEL =
    'input:not([type=hidden]):not([type=checkbox]):not([type=radio]), textarea, select, mat-select, [role=combobox], ng-select';

  function findButton(re, root) {
    const els = [...(root || document).querySelectorAll(
      'button, a, [role=button], [mat-button], [mat-raised-button], [mat-flat-button], .btn'
    )].filter(visible);
    const hits = els.filter((e) => re.test(clean(e.innerText || e.getAttribute('aria-label'))));
    hits.sort((a, b) => clean(a.innerText).length - clean(b.innerText).length);
    return hits[0] || null;
  }

  // Find a form field by its placeholder, aria-label, form control name or label text.
  function findField(re, root) {
    root = root || document;
    const box = (i) => i.closest('mat-form-field') || i;
    for (const i of [...root.querySelectorAll(FIELD_SEL)].filter(visible)) {
      const t = [i.placeholder, i.getAttribute('aria-label'), i.getAttribute('formcontrolname'),
        i.getAttribute('data-placeholder'), i.name, i.id].map(clean).join(' | ');
      if (re.test(t)) return box(i);
    }
    const labels = [...root.querySelectorAll('label, mat-label, span, div, p, h4, h5, h6')]
      .filter((e) => visible(e) && clean(e.innerText).length < 40 && re.test(clean(e.innerText)));
    for (const l of labels) {
      if (l.htmlFor) {
        const i = document.getElementById(l.htmlFor);
        if (visible(i)) return box(i);
      }
      let p = l;
      for (let k = 0; k < 4 && p; k++) {
        const i = [...p.querySelectorAll(FIELD_SEL)].find(visible);
        if (i) return box(i);
        p = p.parentElement;
      }
    }
    return null;
  }

  const steps = [
    { find: () => findButton(/add project$/i),
      text: 'Click <b>+ Add Project</b> to start a new project.' },
    { find: () => findField(/project ?name/i, scope()),
      text: 'Type the <b>Project Name</b>.', next: true },
    { find: () => findField(/prefix/i, scope()),
      text: 'Type a short <b>Document Prefix</b>, for example the project initials. Up to 20 letters, no spaces, and different from your other projects.', next: true },
    { find: () => findField(/address/i, scope()),
      text: 'Type the <b>Home Address</b> of the job. If a list of addresses appears, pick the right one.', next: true, side: 'left' },
    { find: () => findField(/client/i, scope()),
      text: 'Optional: choose the <b>Client</b> for this project, or click Next to skip.', next: true, side: 'left' },
    { find: () => findButton(/^create project$/i, scope()),
      text: 'Click <b>Create Project</b>.' },
  ];

  // Overlay elements.
  const style = document.createElement('style');
  style.textContent =
    '@keyframes rtGuidePulse{0%,100%{outline-color:' + ORANGE + '}50%{outline-color:#ffc38a}}' +
    '#rt-guide-tip button{font:inherit;border-radius:6px;padding:6px 12px;cursor:pointer}';
  const spot = document.createElement('div');
  Object.assign(spot.style, {
    position: 'fixed', zIndex: Z, pointerEvents: 'none', borderRadius: '8px',
    boxShadow: '0 0 0 9999px rgba(0,0,0,0.35)', outline: '3px solid ' + ORANGE, outlineOffset: '2px',
    animation: 'rtGuidePulse 1.4s ease-in-out infinite', transition: 'all .15s ease', display: 'none',
  });
  const tip = document.createElement('div');
  tip.id = 'rt-guide-tip';
  Object.assign(tip.style, {
    position: 'fixed', zIndex: Z + 1, maxWidth: '320px', background: '#fff', color: '#1f2328',
    borderRadius: '10px', padding: '12px 14px', boxShadow: '0 8px 24px rgba(0,0,0,.25)',
    font: '14px/1.45 system-ui,-apple-system,Segoe UI,Roboto,sans-serif', borderTop: '4px solid ' + ORANGE,
  });
  document.body.append(style, spot, tip);

  let step = 0;
  let finished = false;
  let missingSince = 0;
  let dialogSeen = false;
  let urlAtOpen = '';
  let closedSince = 0;
  let shownKey = '';

  function render(html, buttons) {
    const key = html + '|' + buttons.map((b) => b.label).join(',');
    if (key === shownKey) return;
    shownKey = key;
    tip.innerHTML = html + '<div style="display:flex;gap:8px;justify-content:flex-end;margin-top:10px"></div>';
    const row = tip.lastChild;
    for (const b of buttons) {
      const el = document.createElement('button');
      el.textContent = b.label;
      Object.assign(el.style, b.primary
        ? { background: ORANGE, color: '#fff', border: '1px solid ' + ORANGE }
        : { background: '#fff', color: '#1f2328', border: '1px solid #d0d7de' });
      el.onclick = (e) => { e.preventDefault(); e.stopPropagation(); b.onClick(); };
      row.append(el);
    }
  }

  // side 'left' keeps the tip beside the field, so a dropdown opening below it stays visible.
  function place(target, side) {
    const t = tip.getBoundingClientRect();
    const vw = innerWidth, vh = innerHeight, gap = 12;
    let top, left;
    if (target && side === 'left') {
      const r = target.getBoundingClientRect();
      top = Math.max(gap, Math.min(r.top, vh - t.height - gap));
      if (r.left - gap - t.width >= gap) left = r.left - gap - t.width;
      else if (r.right + gap + t.width <= vw - gap) left = r.right + gap;
      else return place(target);
      tip.style.top = top + 'px';
      tip.style.left = left + 'px';
      return;
    }
    if (target) {
      const r = target.getBoundingClientRect();
      top = r.bottom + gap + t.height < vh ? r.bottom + gap : r.top - gap - t.height;
      if (top < gap) top = Math.min(vh - t.height - gap, r.bottom + gap);
      left = r.left;
    } else {
      top = 24;
      left = (vw - t.width) / 2;
    }
    tip.style.top = Math.max(gap, top) + 'px';
    tip.style.left = Math.max(gap, Math.min(left, vw - t.width - gap)) + 'px';
  }

  function go(n) {
    step = n;
    missingSince = 0;
    shownKey = '';
  }

  function finish() {
    finished = true;
    spot.style.display = 'none';
    render('<b>Done.</b> Your project is created. You can now open it and add the estimate, schedule and team.',
      [{ label: 'Close', primary: true, onClick: stop }]);
    place(null);
    setTimeout(stop, 15000);
  }

  function tick() {
    if (finished) return;
    const d = dialog();

    // Track the dialog: open moves past step 1, closing either finishes or restarts.
    if (d && !dialogSeen) {
      dialogSeen = true;
      urlAtOpen = location.href;
      closedSince = 0;
      if (step === 0) go(1);
    }
    if (!d && dialogSeen) {
      closedSince = closedSince || Date.now();
      if (location.href !== urlAtOpen || step === steps.length - 1) {
        if (Date.now() - closedSince > 600) return finish();
      } else if (Date.now() - closedSince > 1200) {
        dialogSeen = false;
        go(0);
      }
    } else {
      closedSince = 0;
    }

    const s = steps[step];
    const target = s.find();
    const head = '<div style="font-size:12px;color:#57606a;margin-bottom:4px">Step ' + (step + 1) + ' of ' + steps.length + '</div>';
    const buttons = [];
    if (s.next) buttons.push({ label: 'Next', primary: true, onClick: () => go(Math.min(step + 1, steps.length - 1)) });
    buttons.push({ label: 'Close guide', onClick: stop });

    if (target) {
      missingSince = 0;
      const r = target.getBoundingClientRect();
      Object.assign(spot.style, {
        display: 'block', top: r.top - 4 + 'px', left: r.left - 4 + 'px',
        width: r.width + 8 + 'px', height: r.height + 8 + 'px',
        // No dimming on dropdown steps, so the open list stays easy to read.
        boxShadow: s.side === 'left' ? 'none' : '0 0 0 9999px rgba(0,0,0,0.35)',
      });
      if (r.top < 0 || r.bottom > innerHeight) target.scrollIntoView({ block: 'center', behavior: 'smooth' });
      render(head + s.text, buttons);
      place(target, s.side);
    } else {
      missingSince = missingSince || Date.now();
      spot.style.display = 'none';
      const lost = Date.now() - missingSince > 2500;
      render(head + s.text + (lost ? '<div style="margin-top:6px;color:#57606a">I can\'t point to it right now. Look for it on the screen and follow this tip.</div>' : ''), buttons);
      place(null);
    }
  }

  const onKey = (e) => { if (e.key === 'Escape') stop(); };
  const timer = setInterval(tick, 150);
  addEventListener('keydown', onKey, true);

  function stop() {
    clearInterval(timer);
    removeEventListener('keydown', onKey, true);
    style.remove(); spot.remove(); tip.remove();
    if (!finished) window.__rtGuide.closedByUser = true;
  }

  window.__rtGuide = {
    stop,
    closedByUser: false,
    status: () => ({ step: step + 1, total: steps.length, finished, closedByUser: window.__rtGuide.closedByUser, url: location.href }),
  };
  tick();
  return 'ReadyTeam guide started: ' + (steps[0].find() ? 'Add Project button found' : 'Add Project button not found yet');
})();
```